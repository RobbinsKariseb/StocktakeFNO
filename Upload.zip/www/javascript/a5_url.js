function calcURL(urlIn)
	{
		return urlIn;
	}
